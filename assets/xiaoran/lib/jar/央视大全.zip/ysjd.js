﻿{
	"classes": [
		{"type_name":"典籍里的中国","type_id": "典籍里的中国"},
		{"type_name":"朗读者","type_id": "朗读者"},
		{"type_name":"我爱发明","type_id": "CCTV 我爱发明"},
		{"type_name":"《读书的力量》","type_id": "《读书的力量》"},
		{"type_name":"国宝发现","type_id": "国宝发现"},
		{"type_name":"国宝档案","type_id": "国宝档案"},

		{"type_name":"人体奥秘","type_id": "小灯塔人体奥秘"},
		{"type_name":"给男孩的性教育课","type_id": "小灯塔给男孩的性教育课"}
	]
}