[{
     "type_id": "EPGC1386744804340101",
     "type_name": "CCTV-1综合"
 },{
     "type_id": "EPGC1386744804340102",
     "type_name": "CCTV-2财经"
 },{
     "type_id": "EPGC1386744804340103",
     "type_name": "CCTV3-综艺"
 },{
     "type_id": "EPGC1386744804340104",
     "type_name": "CCTV4-中文国际"
 },{
     "type_id": "EPGC1386744804340107",
     "type_name": "CCTV5-体育"
 },{
     "type_id": "EPGC1468294755566101",
     "type_name": "CCTV5+体育赛事"
 },{
     "type_id": "EPGC1386744804340108",
     "type_name": "CCTV6-电影"
 },{
     "type_id": "EPGC1386744804340109",
     "type_name": "CCTV-7国防军事"
 },{
     "type_id": "EPGC1386744804340110",
     "type_name": "CCTV-8电视剧"
 },{
     "type_id": "EPGC1386744804340112",
     "type_name": "CCTV-9纪录"
 },{
     "type_id": "EPGC1386744804340113",
     "type_name": "CCTV-10科教"
 },{
     "type_id": "EPGC1386744804340114",
     "type_name": "CCTV-11戏曲"
 },{
     "type_id": "EPGC1386744804340115",
     "type_name": "CCTV-12社会与法"
 },{
     "type_id": "EPGC1386744804340116",
     "type_name": "CCTV-13新闻"
 },{
     "type_id": "EPGC1386744804340117",
     "type_name": "CCTV-14少儿"
 },{
     "type_id": "EPGC1386744804340118",
     "type_name": "CCTV-15音乐"
 },{
     "type_id": "EPGC1634630207058998",
     "type_name": "CCTV-16奥林匹克"
 },{
     "type_id": "EPGC1563932742616872",
     "type_name": "CCTV-17农业农村"
 }]