#!/data/data/com.termux/files/usr/bin/bash
# ==============================================================================
# 功能：全自动 GitHub 仓库重建 + 强制镜像（仅保留 main 分支，修复 Token 与 SSH 问题）
# 特点：
#  1. 支持 Token 有效性预检查
#  2. 自动处理 SSH 密钥问题（兼容 HTTPS 兜底）
#  3. 修复空提交信息导致的失败
# ==============================================================================

# ====================== 配置区（必须修改！） ======================
ACCESS_TOKEN="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"  # 已验证的有效 Token
USERNAME="abner0006"          # GitHub 用户名
REPO_NAME="update"            # 仓库名称
PROJECT_DIR="/storage/emulated/0/.Auto/update"  # 本地项目路径
MAIN_BRANCH="main"            # 固定 main 分支
COMMIT_MSG="Force sync: 删库重建后镜像本地内容"  # 避免空提交
REMOTE_REPO_SSH="git@github.com:${USERNAME}/${REPO_NAME}.git"  # SSH 地址
REMOTE_REPO_HTTPS="https://${ACCESS_TOKEN}@github.com/${USERNAME}/${REPO_NAME}.git"  # HTTPS 地址（Token 认证）

# ====================== 0. 预检查：Token 有效性（新增！） ======================
echo "[0/7] 预检查：验证 GitHub Token 有效性..."
TOKEN_CHECK=$(curl -s -w "%{http_code}" \
  -H "Authorization: token ${ACCESS_TOKEN}" \
  "https://api.github.com/user"
)
if echo "$TOKEN_CHECK" | grep -q "200"; then
  echo "→ Token 有效，继续执行..."
else
  echo "❌ Token 无效！报错：$(echo "$TOKEN_CHECK" | grep -oP '(?<="message":")[^"]+')"
  exit 1
fi

# ====================== 1. 配置 SSH 信任（优化：兼容 HTTPS 兜底） ======================
echo "[1/7] 配置 SSH 信任 GitHub 主机（失败则自动切换 HTTPS）..."
mkdir -p ~/.ssh
ssh-keyscan -t rsa github.com >> ~/.ssh/known_hosts 2>/dev/null
chmod 600 ~/.ssh/known_hosts

# 测试 SSH 连接，失败则切换 HTTPS
ssh -T git@github.com -o ConnectTimeout=5 >/dev/null 2>&1
if [ $? -ne 0 ]; then
  echo "→ SSH 连接失败，自动切换为 HTTPS 推送"
  REMOTE_REPO="${REMOTE_REPO_HTTPS}"
else
  REMOTE_REPO="${REMOTE_REPO_SSH}"
  echo "→ SSH 连接成功，使用 SSH 推送"
fi

# ====================== 2. 检查并清空远程仓库（删除所有分支） ======================
echo "[2/7] 检查并清空远程仓库（仅保留 ${MAIN_BRANCH}）..."
REMOTE_BRANCHES=$(git ls-remote --heads $REMOTE_REPO | awk '{print $2}' | grep -v "refs/heads/${MAIN_BRANCH}")

for BRANCH in $REMOTE_BRANCHES; do
  BRANCH_NAME=$(echo $BRANCH | sed 's/refs\/heads\///')
  echo "→ 删除远程分支：${BRANCH_NAME}"
  git push origin --delete $BRANCH_NAME || echo "→ 分支 ${BRANCH_NAME} 删除失败（可能已不存在）"
done

# ====================== 3. 检查并创建仓库（仅保留 main） ======================
echo "[3/7] 检查并创建仓库（默认分支：${MAIN_BRANCH}）..."
CHECK_REPO=$(curl -s -w "%{http_code}" \
  -H "Authorization: token ${ACCESS_TOKEN}" \
  "https://api.github.com/repos/${USERNAME}/${REPO_NAME}"
)

if echo "$CHECK_REPO" | grep -q "Not Found"; then
  echo "→ 仓库不存在，创建空仓库..."
  CREATE_REPO=$(curl -s -w "%{http_code}" -X POST \
    -H "Authorization: token ${ACCESS_TOKEN}" \
    -H "Content-Type: application/json" \
    -d "{
      \"name\": \"${REPO_NAME}\",
      \"default_branch\": \"${MAIN_BRANCH}\",
      \"auto_init\": false,
      \"private\": false
    }" \
    "https://api.github.com/user/repos"
  )
  if echo "$CREATE_REPO" | grep -q "\"id\":"; then
    echo "→ 仓库创建成功！"
  else
    echo "❌ 创建失败：$(echo "$CREATE_REPO" | grep -oP '(?<="message":")[^"]+')"
    exit 1
  fi
else
  echo "→ 仓库已存在，跳过创建。"
fi

# ====================== 4. 进入本地目录 ======================
echo "[4/7] 进入本地项目目录..."
cd $PROJECT_DIR || { echo "❌ 目录不存在：${PROJECT_DIR}，退出！"; exit 1; }

# 检查目录是否为空（新增！避免空推送）
if [ -z "$(ls -A $PROJECT_DIR)" ]; then
  echo "❌ 本地目录为空，请确认文件已正确放置"
  exit 1
fi

# ====================== 5. 清理旧 Git 记录（核心：纯净初始化） ======================
echo "[5/7] 清理旧 Git 记录，准备全新镜像..."
rm -rf .git  # 销毁本地历史
git init  # 重新初始化

# ====================== 6. 初始化 Git 并关联远程 ======================
echo "[6/7] 关联远程仓库：${REMOTE_REPO}"
git remote add origin $REMOTE_REPO

# ====================== 7. 强制推送全新镜像（核心：覆盖 main） ======================
echo "[7/7] 强制同步到 ${MAIN_BRANCH} 分支..."
git checkout -b $MAIN_BRANCH
git add .
git commit -m "$COMMIT_MSG"  # 确保提交信息非空

# 强制推送（增加超时重试，应对网络问题）
if ! git push --force --set-upstream origin $MAIN_BRANCH; then
  echo "❌ 推送失败，尝试 HTTPS 兜底..."
  git remote set-url origin $REMOTE_REPO_HTTPS
  git push --force --set-upstream origin $MAIN_BRANCH
fi

# ====================== 结果反馈 ======================
if [ $? -eq 0 ]; then
  echo -e "\n✅ 操作完成！远程仓库状态："
  echo "→ 仓库地址：${REMOTE_REPO}"
  echo "→ 分支：仅 ${MAIN_BRANCH}，内容与本地一致"
else
  echo -e "\n❌ 最终失败！检查："
  echo "  1. 本地目录 ${PROJECT_DIR} 是否有文件"
  echo "  2. GitHub Token 权限（需 repo 全权限）"
  echo "  3. 网络连接（切换 Wi-Fi/移动数据重试）"
  exit 1
fi
