import os
import subprocess
import sys
import time
from datetime import datetime
import shutil
import re

def clear_screen():
    """清空终端屏幕"""
    os.system('cls' if os.name == 'nt' else 'clear')

def print_header():
    """打印脚本标题"""
    print("==================================================")
    print("          GitHub 全新项目上传工具")
    print("==================================================")
    print("功能: 将本地项目作为全新仓库上传到 GitHub")
    print("特点: 清除原有 Git 历史记录，实现首次上传效果")
    print("==================================================")

def get_user_input():
    """获取用户输入"""
    print("\n[配置信息]")
    project_dir = input("请输入本地项目路径: ").strip()
    remote_repo = input("请输入 GitHub 仓库 SSH 地址: ").strip()
    branch_name = input("请输入分支名称 (默认为 main): ").strip() or "main"
    commit_msg = input("请输入提交信息 (默认为 '全新上传，初始化仓库'): ").strip() or "全新上传，初始化仓库"
    
    return project_dir, remote_repo, branch_name, commit_msg

def log(message, level="INFO", color_code=""):
    """带颜色和时间的日志输出"""
    timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    
    # 颜色代码
    colors = {
        "HEADER": "\033[95m",
        "INFO": "\033[94m",
        "SUCCESS": "\033[92m",
        "WARNING": "\033[93m",
        "ERROR": "\033[91m",
        "ENDC": "\033[0m",
    }
    
    color = colors.get(level, "") if not color_code else color_code
    endc = colors["ENDC"]
    
    print(f"{color}[{timestamp}] {level}: {message}{endc}")

def run_command(command, check=True, capture_output=True):
    """执行命令并返回结果"""
    log(f"执行命令: {command}", "INFO")
    
    try:
        result = subprocess.run(
            command,
            shell=True,
            check=check,
            stdout=subprocess.PIPE if capture_output else None,
            stderr=subprocess.PIPE if capture_output else None,
            text=True
        )
        
        if capture_output and result.stdout:
            log(f"输出: {result.stdout.strip()}", "DEBUG", "\033[90m")
        
        return result
    except subprocess.CalledProcessError as e:
        log(f"命令执行失败: {e.stderr if e.stderr else str(e)}", "ERROR")
        raise

def check_ssh_config():
    """检查 SSH 配置"""
    log("检查 SSH 配置...")
    
    try:
        # 测试 GitHub SSH 连接
        result = run_command("ssh -T git@github.com", check=False)
        
        if "successfully authenticated" in result.stderr:
            log("SSH 连接验证成功", "SUCCESS")
            return True
        else:
            log("SSH 连接失败，请检查配置", "WARNING")
            log("解决方案: 请确保已生成 SSH 密钥并添加到 GitHub", "WARNING")
            log("1. 生成新密钥: ssh-keygen -t ed25519 -C \"your_email@example.com\"", "WARNING")
            log("2. 添加公钥到 GitHub: cat ~/.ssh/id_ed25519.pub", "WARNING")
            log("3. 测试连接: ssh -T git@github.com", "WARNING")
            return False
    except Exception as e:
        log(f"SSH 检查出错: {str(e)}", "ERROR")
        return False

def clean_local_git(project_dir):
    """清理本地 Git 历史记录"""
    git_dir = os.path.join(project_dir, ".git")
    
    if os.path.exists(git_dir):
        log(f"删除本地 Git 记录: {git_dir}", "INFO")
        shutil.rmtree(git_dir)
        return True
    else:
        log("未找到 .git 目录，跳过清理", "INFO")
        return True

def init_and_push(project_dir, remote_repo, branch_name, commit_msg):
    """初始化 Git 仓库并推送到远程"""
    # 进入项目目录
    os.chdir(project_dir)
    log(f"当前工作目录: {os.getcwd()}", "INFO")
    
    # 初始化 Git 仓库
    run_command("git init")
    
    # 添加远程仓库
    run_command(f"git remote add origin {remote_repo}")
    
    # 创建并切换到分支
    run_command(f"git checkout -b {branch_name}")
    
    # 添加所有文件
    run_command("git add .")
    
    # 提交更改
    run_command(f"git commit -m \"{commit_msg}\"")
    
    # 强制推送
    try:
        run_command(f"git push --force --set-upstream origin {branch_name}")
        log("推送成功！", "SUCCESS")
        return True
    except subprocess.CalledProcessError:
        log("推送失败，尝试解决可能的分支问题...", "WARNING")
        
        # 尝试替代推送命令
        try:
            run_command(f"git push -f origin HEAD:{branch_name}")
            log("使用替代命令推送成功！", "SUCCESS")
            return True
        except subprocess.CalledProcessError as e:
            log(f"推送最终失败: {e.stderr}", "ERROR")
            return False

def verify_local_git():
    """验证本地 Git 状态"""
    try:
        # 检查提交历史
        log("验证本地提交历史...", "INFO")
        history = run_command("git log --oneline", capture_output=True)
        
        if history.stdout:
            log(f"本地提交记录:\n{history.stdout}", "INFO")
            return True
        else:
            log("未找到本地提交记录", "ERROR")
            return False
    except Exception as e:
        log(f"本地验证失败: {str(e)}", "ERROR")
        return False

def main():
    clear_screen()
    print_header()
    
    # 获取用户输入
    project_dir, remote_repo, branch_name, commit_msg = get_user_input()
    
    # 验证路径是否存在
    if not os.path.exists(project_dir):
        log(f"路径不存在: {project_dir}", "ERROR")
        sys.exit(1)
    
    # 检查 SSH 配置
    if not check_ssh_config():
        log("SSH 配置检查失败，请先解决问题", "ERROR")
        sys.exit(1)
    
    # 清理本地 Git 记录
    if not clean_local_git(project_dir):
        log("清理本地 Git 记录失败", "ERROR")
        sys.exit(1)
    
    # 初始化并推送
    log("\n开始上传流程...", "HEADER")
    if init_and_push(project_dir, remote_repo, branch_name, commit_msg):
        log("\n上传成功！请完成以下验证：", "SUCCESS")
        log("1. 访问 GitHub 查看仓库文件", "SUCCESS")
        log("2. 检查文件列表是否与本地一致", "SUCCESS")
        log("3. 确认提交记录显示正确", "SUCCESS")
        
        # 本地验证
        if verify_local_git():
            log("本地 Git 状态验证成功", "SUCCESS")
        else:
            log("本地 Git 状态验证存在问题，请手动检查", "WARNING")
    else:
        log("\n上传失败，请检查错误信息", "ERROR")
        log("常见问题解决方案:", "WARNING")
        log("1. Permission denied: 检查 SSH 密钥配置", "WARNING")
        log("2. src refspec 错误: 确保已创建分支并提交", "WARNING")
        log("3. 远程仓库不存在: 检查远程仓库地址是否正确", "WARNING")
        log("4. 敏感内容错误: 检查是否包含密钥或令牌文件", "WARNING")
        sys.exit(1)

if __name__ == "__main__":
    try:
        main()
    except KeyboardInterrupt:
        print("\n操作已取消")
        sys.exit(0)