#!/data/data/com.termux/files/usr/bin/bash
# ==============================================================================
# 功能：全新初始化 Gitee 仓库（仅保留 master 分支，强制镜像本地内容）
# 特点：删除远程所有多余分支，仅保留 master，实现纯镜像初始化
# ==============================================================================

# ====================== 配置区（按需修改） ======================
ACCESS_TOKEN="f1c2451a7f139023f6fa07ce4553333e"  # Gitee 令牌（需 repo 权限）
USERNAME="xiaoranmuze"          # Gitee 用户名
REPO_NAME="update"                # 仓库名称
PROJECT_DIR="/storage/emulated/0/.Auto/update"  # 本地项目路径
MASTER_BRANCH="master"          # 仅保留的分支（Gitee 默认分支mastet）
COMMIT_MSG="全新初始化：强制镜像本地内容"  # 提交信息
REMOTE_REPO="git@gitee.com:${USERNAME}/${REPO_NAME}.git"

# ====================== 1. 配置 SSH 信任 ======================
echo "[1/7] 配置 SSH 信任 Gitee 主机..."
mkdir -p ~/.ssh
ssh-keyscan -t rsa gitee.com >> ~/.ssh/known_hosts 2>/dev/null
chmod 600 ~/.ssh/known_hosts

# ====================== 2. 检查并清空远程仓库（删除所有分支） ======================
echo "[2/7] 检查并清空远程仓库（删除所有分支，仅保留 ${MASTER_BRANCH}）..."
# 获取远程所有分支（除 master）
REMOTE_BRANCHES=$(git ls-remote --heads $REMOTE_REPO | awk '{print $2}' | grep -v "refs/heads/${MASTER_BRANCH}")

# 删除远程多余分支
for BRANCH in $REMOTE_BRANCHES; do
  BRANCH_NAME=$(echo $BRANCH | sed 's/refs\/heads\///')
  echo "→ 删除远程分支：${BRANCH_NAME}"
  git push origin --delete $BRANCH_NAME
done

# ====================== 3. 检查并创建仓库（仅保留 master） ======================
echo "[3/7] 检查并创建仓库（默认分支：${MASTER_BRANCH}）..."
CHECK_REPO=$(curl -s -w "%{http_code}" "https://gitee.com/api/v5/repos/${USERNAME}/${REPO_NAME}" \
  -H "Authorization: token ${ACCESS_TOKEN}")

if echo "$CHECK_REPO" | grep -q "Not Found"; then
  echo "→ 仓库不存在，创建空仓库（仅 ${MASTER_BRANCH} 分支）..."
  CREATE_REPO=$(curl -s -w "%{http_code}" -X POST "https://gitee.com/api/v5/repos" \
    -H "Authorization: token ${ACCESS_TOKEN}" \
    -H "Content-Type: application/json" \
    -d "{
      \"name\": \"${REPO_NAME}\",
      \"default_branch\": \"${MASTER_BRANCH}\",  # 仅保留 master
      \"auto_init\": false,  # 不初始化（避免默认文件）
      \"private\": false,
      \"access_token\": \"${ACCESS_TOKEN}\"
    }")
  if echo "$CREATE_REPO" | grep -q "\"id\":"; then
    echo "→ 仓库创建成功（仅 ${MASTER_BRANCH} 分支）！"
  else
    echo "→ 创建失败：$(echo "$CREATE_REPO" | grep -oP '(?<="message":")[^"]+')"
    exit 1
  fi
else
  echo "→ 仓库已存在（仅保留 ${MASTER_BRANCH} 分支），跳过创建。"
fi

# ====================== 4. 进入本地目录 ======================
echo "[4/7] 进入本地项目目录..."
cd $PROJECT_DIR || { echo "→ 目录不存在，退出！"; exit 1; }

# ====================== 5. 清理旧 Git 记录（核心：纯净初始化） ======================
echo "[5/7] 清理旧 Git 记录，准备全新镜像..."
rm -rf .git  # 销毁本地所有历史，确保纯净

# ====================== 6. 初始化 Git 并关联远程 ======================
echo "[6/7] 初始化 Git 仓库（仅 ${MASTER_BRANCH} 分支）..."
git init
git remote add origin $REMOTE_REPO

# ====================== 7. 强制推送全新镜像（核心：覆盖 master） ======================
echo "[7/7] 强制同步到 ${MASTER_BRANCH} 分支（全新初始化）..."
git checkout -b $MASTER_BRANCH  # 仅创建 master 分支
git add .
git commit -m "$COMMIT_MSG"
git push --force --set-upstream origin $MASTER_BRANCH  # 强制覆盖

# ====================== 结果反馈 ======================
if [ $? -eq 0 ]; then
  echo -e "\n✅ 全新初始化完成！远程仓库仅保留 ${MASTER_BRANCH} 分支，与本地完全一致："
  echo "→ 仓库地址：${REMOTE_REPO}"
  echo "→ 分支状态：仅 ${MASTER_BRANCH}（无任何多余分支）"
else
  echo -e "\n❌ 初始化失败，检查 SSH 密钥或网络。"
  exit 1
