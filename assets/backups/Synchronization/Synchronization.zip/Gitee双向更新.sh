#!/data/data/com.termux/files/usr/bin/bash
# 功能：Gitee 双向同步脚本（本地↔远程）
# 说明：保留原始脚本结构，仅同步变更，自动修复.git问题，支持双向更新

# ====================== 配置信息（请根据实际情况修改） ======================
ACCESS_TOKEN="f1c2451a7f139023f6fa07ce4553333e"  # Gitee 令牌（需 repo 权限）
USERNAME="xiaoranmuze"          # Gitee 用户名
REPO_NAME="update"                # 仓库名称
PROJECT_DIR="/storage/emulated/0/.Auto/update"  # 本地项目路径
MASTER_BRANCH="master"          # 主分支名称
COMMIT_MSG="双向同步：更新本地与远程内容"  # 提交说明
REMOTE_REPO="git@gitee.com:${USERNAME}/${REPO_NAME}.git"  # 远程仓库地址

# ====================== 1. 配置 SSH 信任（连接 Gitee 必备） ======================
echo "[1/7] 配置 SSH 信任，确保能连接 Gitee..."
mkdir -p ~/.ssh
ssh-keyscan -t rsa gitee.com >> ~/.ssh/known_hosts 2>/dev/null
chmod 600 ~/.ssh/known_hosts

# ====================== 2. 保留远程分支（不删除任何分支） ======================
echo "[2/7] 保留所有远程分支，不执行删除操作..."
# 以下为原始代码（已注释，不执行删除）
REMOTE_BRANCHES=$(git ls-remote --heads $REMOTE_REPO | awk '{print $2}' | grep -v "refs/heads/${MASTER_BRANCH}")
# for BRANCH in $REMOTE_BRANCHES; do
#   BRANCH_NAME=$(echo $BRANCH | sed 's/refs\/heads\///')
#   echo "→ 删除远程分支：${BRANCH_NAME}"
#   git push origin --delete $BRANCH_NAME
# done

# ====================== 3. 检查并创建仓库（不存在则新建） ======================
echo "[3/7] 检查仓库是否存在，不存在则自动创建..."
CHECK_REPO=$(curl -s -w "%{http_code}" "https://gitee.com/api/v5/repos/${USERNAME}/${REPO_NAME}" \
  -H "Authorization: token ${ACCESS_TOKEN}")

if echo "$CHECK_REPO" | grep -q "Not Found"; then
  echo "→ 仓库不存在，开始创建空仓库..."
  CREATE_REPO=$(curl -s -w "%{http_code}" -X POST "https://gitee.com/api/v5/repos" \
    -H "Authorization: token ${ACCESS_TOKEN}" \
    -H "Content-Type: application/json" \
    -d "{
      \"name\": \"${REPO_NAME}\",
      \"default_branch\": \"${MASTER_BRANCH}\",
      \"auto_init\": false,
      \"private\": false,
      \"access_token\": \"${ACCESS_TOKEN}\"
    }")
  if echo "$CREATE_REPO" | grep -q "\"id\":"; then
    echo "→ 仓库创建成功！"
  else
    echo "→ 创建失败：$(echo "$CREATE_REPO" | grep -oP '(?<="message":")[^"]+')"
    exit 1
  fi
else
  echo "→ 仓库已存在，跳过创建..."
fi

# ====================== 4. 进入本地项目目录 ======================
echo "[4/7] 进入本地项目目录..."
cd $PROJECT_DIR || { echo "→ 目录不存在，退出！"; exit 1; }

# 【新增】双向同步：先拉取远程最新内容到本地
echo "[4/7 补充] 拉取远程最新更新到本地（确保本地是最新的）..."
if [ -d ".git" ]; then
  git fetch origin
  git pull origin $MASTER_BRANCH --rebase
else
  echo "→ 本地未初始化仓库，首次运行将直接推送..."
fi

# ====================== 5. 保留本地 Git 记录（不删除.git） ======================
echo "[5/7] 保留本地 Git 历史，不清理..."
# 原始清理代码（已注释，不执行）
# rm -rf .git

# 【新增】自动修复.git目录（删除后自动重建）
echo "[5/7 补充] 检查.git目录，丢失则自动修复..."
if [ ! -d ".git" ]; then
  echo "→ .git目录丢失，重建并同步远程历史..."
  git init
  git remote add origin $REMOTE_REPO
  git fetch origin
  git reset --hard origin/$MASTER_BRANCH
fi

# ====================== 6. 初始化并关联远程仓库 ======================
echo "[6/7] 初始化Git并关联远程仓库..."
git init
git remote add origin $REMOTE_REPO

# 【新增】同步远程分支信息
echo "[6/7 补充] 同步远程分支信息..."
git fetch origin

# ====================== 7. 推送本地变更到远程 ======================
echo "[7/7] 推送本地变更到远程仓库..."
# 切换到主分支
if git show-ref --verify --quiet "refs/heads/${MASTER_BRANCH}"; then
  git checkout $MASTER_BRANCH
else
  git checkout -b $MASTER_BRANCH
fi
git add .  # 添加所有变更
git commit -m "$COMMIT_MSG"  # 提交变更

# 【新增】推送前再次拉取，避免冲突
echo "[7/7 补充] 再次拉取远程更新（防止冲突）..."
git pull origin $MASTER_BRANCH --rebase 2>/dev/null || true

# 推送本地变更（非强制）
git push --set-upstream origin $MASTER_BRANCH

# ====================== 结果反馈 ======================
if [ $? -eq 0 ]; then
  echo -e "\n✅ 双向同步完成！"
  echo "→ 仓库地址：${REMOTE_REPO}"
  echo "→ 本地和远程已同步一致"
else
  echo -e "\n❌ 同步失败，检查网络或权限..."
  exit 1
fi
