#!/data/data/com.termux/files/usr/bin/bash
# 功能：GitHub 单向同步脚本（仅远程→本地更新）
# 说明：保留原始脚本结构，仅拉取远程变更到本地，不推送本地内容，自动修复.git问题

# ====================== 配置信息（已适配GitHub） ======================
ACCESS_TOKEN="f1c2451a7f139023f6fa07ce4553333e"  # GitHub令牌（需repo权限）
USERNAME="abner0006"          # GitHub用户名
REPO_NAME="update"              # 仓库名称
PROJECT_DIR="/storage/emulated/0/.Auto/update"  # 本地项目路径
MAIN_BRANCH="main"            # GitHub主分支（默认main）
COMMIT_MSG="单向同步：拉取远程变更到本地"  # 提交说明（改为远程→本地）
REMOTE_REPO="git@github.com:${USERNAME}/${REPO_NAME}.git"  # GitHub仓库地址

# ====================== 1. 配置SSH信任（连接GitHub必备） ======================
echo "[1/10] 配置SSH信任，确保能连接GitHub..."
mkdir -p ~/.ssh
ssh-keyscan -t rsa github.com >> ~/.ssh/known_hosts 2>/dev/null
chmod 600 ~/.ssh/known_hosts

# ====================== 2. 保留远程分支（不删除任何分支） ======================
echo "[2/10] 保留所有远程分支，不执行删除操作..."
# 以下为原始代码（已注释，不执行删除）
REMOTE_BRANCHES=$(git ls-remote --heads $REMOTE_REPO | awk '{print $2}' | grep -v "refs/heads/${MAIN_BRANCH}")
# for BRANCH in $REMOTE_BRANCHES; do
#   BRANCH_NAME=$(echo $BRANCH | sed 's/refs\/heads\///')
#   echo "→ 删除远程分支：${BRANCH_NAME}"
#   git push origin --delete $BRANCH_NAME
# done

# ====================== 3. 检查并创建仓库（不存在则新建） ======================
echo "[3/10] 检查仓库是否存在，不存在则自动创建..."
CHECK_REPO=$(curl -s -w "%{http_code}" "https://api.github.com/repos/${USERNAME}/${REPO_NAME}" \
  -H "Authorization: token ${ACCESS_TOKEN}")

if echo "$CHECK_REPO" | grep -q "Not Found"; then
  echo "→ 仓库不存在，开始创建空仓库..."
  CREATE_REPO=$(curl -s -w "%{http_code}" -X POST "https://api.github.com/user/repos" \
    -H "Authorization: token ${ACCESS_TOKEN}" \
    -H "Content-Type: application/json" \
    -d "{
      \"name\": \"${REPO_NAME}\",
      \"default_branch\": \"${MAIN_BRANCH}\",
      \"auto_init\": false,
      \"private\": false
    }")
  if echo "$CREATE_REPO" | grep -q "\"id\":"; then
    echo "→ 仓库创建成功！"
  else
    echo "→ 创建失败：$(echo "$CREATE_REPO" | grep -oP '(?<="message":")[^"]+')"
    exit 1
  fi
else
  echo "→ 仓库已存在，跳过创建..."
fi

# ====================== 4. 进入本地项目目录 ======================
echo "[4/10] 进入本地项目目录..."
cd $PROJECT_DIR || { echo "→ 目录不存在，退出！"; exit 1; }

# 【核心】单向同步：拉取远程最新内容到本地（仅远程→本地）
echo "[5/10] 拉取远程最新更新到本地（同步方向：远程→本地）..."
if [ -d ".git" ]; then
  git fetch origin  # 同步远程分支信息
  git pull origin $MAIN_BRANCH --rebase  # 拉取并合并远程内容到本地
else
  echo "→ 本地未初始化仓库，首次运行将初始化并拉取远程内容..."
fi

# ====================== 5. 保留本地Git记录（不删除.git） ======================
echo "[6/10] 保留本地Git历史，不清理..."
# 原始清理代码（已注释，不执行）
# rm -rf .git

# 【新增】自动修复.git目录（删除后自动重建）
echo "[7/10] 检查.git目录，丢失则自动修复..."
if [ ! -d ".git" ]; then
  echo "→ .git目录丢失，重建并同步远程历史..."
  git init
  git remote add origin $REMOTE_REPO
  git fetch origin  # 拉取远程历史
  git reset --hard origin/$MAIN_BRANCH  # 同步远程内容到本地
fi

# ====================== 6. 初始化并关联远程仓库 ======================
echo "[8/10] 初始化Git并关联远程仓库..."
git init
git remote add origin $REMOTE_REPO

# 【新增】同步远程分支信息
echo "[9/10] 同步远程分支信息..."
git fetch origin

# ====================== 7. 仅拉取远程内容，不推送本地变更 ======================
echo "[10/10] 确认远程内容已同步到本地（不推送本地变更）..."
# 切换到主分支（确保在正确分支拉取）
if git show-ref --verify --quiet "refs/heads/${MAIN_BRANCH}"; then
  git checkout $MAIN_BRANCH
else
  git checkout -b $MAIN_BRANCH
fi

# 【移除本地→远程推送逻辑】不执行git add/commit/push，仅保留拉取
# git add .
# git commit -m "$COMMIT_MSG"
# git push --set-upstream origin $MAIN_BRANCH

# ====================== 结果反馈 ======================
if [ $? -eq 0 ]; then
  echo -e "\n✅ 单向同步完成！远程最新内容已同步到本地"
  echo "→ 仓库地址：${REMOTE_REPO}"
  echo "→ 同步方向：仅远程→本地（不推送本地变更）"
else
  echo -e "\n❌ 同步失败，检查网络或权限..."
  exit 1
fi
