#!/data/data/com.termux/files/usr/bin/bash
# 功能：GitHub 单向同步脚本（仅本地→远程更新）
# 说明：保留原始脚本结构，仅推送本地变更到远程，不主动拉取远程内容，自动修复.git问题

# ====================== 配置信息（已适配GitHub） ======================
ACCESS_TOKEN="f1c2451a7f139023f6fa07ce4553333e"  # GitHub令牌（需repo权限）
USERNAME="abner0006"          # GitHub用户名
REPO_NAME="update"              # 仓库名称
PROJECT_DIR="/storage/emulated/0/.Auto/update"  # 本地项目路径
MAIN_BRANCH="main"            # GitHub主分支（默认main）
COMMIT_MSG="单向同步：推送本地变更到远程"  # 提交说明（改为单向同步）
REMOTE_REPO="git@github.com:${USERNAME}/${REPO_NAME}.git"  # GitHub仓库地址

# ====================== 1. 配置SSH信任（连接GitHub必备） ======================
echo "[1/10] 配置SSH信任，确保能连接GitHub..."
mkdir -p ~/.ssh
ssh-keyscan -t rsa github.com >> ~/.ssh/known_hosts 2>/dev/null
chmod 600 ~/.ssh/known_hosts

# ====================== 2. 保留远程分支（不删除任何分支） ======================
echo "[2/10] 保留所有远程分支，不执行删除操作..."
# 以下为原始代码（已注释，不执行删除）
REMOTE_BRANCHES=$(git ls-remote --heads $REMOTE_REPO | awk '{print $2}' | grep -v "refs/heads/${MAIN_BRANCH}")
# for BRANCH in $REMOTE_BRANCHES; do
#   BRANCH_NAME=$(echo $BRANCH | sed 's/refs\/heads\///')
#   echo "→ 删除远程分支：${BRANCH_NAME}"
#   git push origin --delete $BRANCH_NAME
# done

# ====================== 3. 检查并创建仓库（不存在则新建） ======================
echo "[3/10] 检查仓库是否存在，不存在则自动创建..."
CHECK_REPO=$(curl -s -w "%{http_code}" "https://api.github.com/repos/${USERNAME}/${REPO_NAME}" \
  -H "Authorization: token ${ACCESS_TOKEN}")

if echo "$CHECK_REPO" | grep -q "Not Found"; then
  echo "→ 仓库不存在，开始创建空仓库..."
  CREATE_REPO=$(curl -s -w "%{http_code}" -X POST "https://api.github.com/user/repos" \
    -H "Authorization: token ${ACCESS_TOKEN}" \
    -H "Content-Type: application/json" \
    -d "{
      \"name\": \"${REPO_NAME}\",
      \"default_branch\": \"${MAIN_BRANCH}\",
      \"auto_init\": false,
      \"private\": false
    }")
  if echo "$CREATE_REPO" | grep -q "\"id\":"; then
    echo "→ 仓库创建成功！"
  else
    echo "→ 创建失败：$(echo "$CREATE_REPO" | grep -oP '(?<="message":")[^"]+')"
    exit 1
  fi
else
  echo "→ 仓库已存在，跳过创建..."
fi

# ====================== 4. 进入本地项目目录 ======================
echo "[4/10] 进入本地项目目录..."
cd $PROJECT_DIR || { echo "→ 目录不存在，退出！"; exit 1; }

# 【移除双向拉取】删除远程→本地的拉取逻辑，仅保留本地→远程推送

# ====================== 5. 保留本地Git记录（不删除.git） ======================
echo "[5/10] 保留本地Git历史，不清理..."
# 原始清理代码（已注释，不执行）
# rm -rf .git

# 【新增】自动修复.git目录（删除后自动重建）
echo "[6/10] 检查.git目录，丢失则自动修复..."
if [ ! -d ".git" ]; then
  echo "→ .git目录丢失，重建并关联远程仓库..."
  git init
  git remote add origin $REMOTE_REPO
  git fetch origin  # 仅同步远程信息，不主动拉取内容
fi

# ====================== 6. 初始化并关联远程仓库 ======================
echo "[7/10] 初始化Git并关联远程仓库..."
git init
git remote add origin $REMOTE_REPO

# 【新增】同步远程分支信息
echo "[8/10] 同步远程分支信息..."
git fetch origin

# ====================== 7. 推送本地变更到远程 ======================
echo "[9/10] 推送本地变更到远程仓库..."
# 切换到主分支
if git show-ref --verify --quiet "refs/heads/${MAIN_BRANCH}"; then
  git checkout $MAIN_BRANCH
else
  git checkout -b $MAIN_BRANCH
fi
git add .  # 添加所有变更
git commit -m "$COMMIT_MSG"  # 提交变更

# 【移除推送前拉取】不主动拉取远程内容，仅推送本地变更
# echo "[10/10] 再次拉取远程更新（防止冲突）..."
# git pull origin $MAIN_BRANCH --rebase 2>/dev/null || true

# 推送本地变更（非强制）
git push --set-upstream origin $MAIN_BRANCH

# ====================== 结果反馈 ======================
if [ $? -eq 0 ]; then
  echo -e "\n✅ 单向同步完成！本地变更已推送至远程"
  echo "→ 仓库地址：${REMOTE_REPO}"
  echo "→ 同步方向：仅本地→远程（不主动拉取远程内容）"
else
  echo -e "\n❌ 同步失败，检查网络或权限..."
  exit 1
fi
