#!/data/data/com.termux/files/usr/bin/bash
# ==============================================================================
# 功能：全新初始化 GitHub 仓库（仅保留 main 分支，强制镜像本地内容）
# 特点：删除远程所有多余分支，仅保留 main，实现纯镜像初始化
# ==============================================================================

# ====================== 配置区（按需修改） ======================
ACCESS_TOKEN="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"  # GitHub 令牌（需 repo 权限）
USERNAME="abner0006"          # GitHub 用户名
REPO_NAME="update"                          # 仓库名称
PROJECT_DIR="/storage/emulated/0/.Auto/update"  # 本地项目路径
MAIN_BRANCH="main"                        # GitHub 默认分支为 main
COMMIT_MSG="全新初始化：强制镜像本地内容"  # 提交信息
REMOTE_REPO="git@github.com:${USERNAME}/${REPO_NAME}.git"  # GitHub 仓库地址

# ====================== 1. 配置 SSH 信任 ======================
echo "[1/7] 配置 SSH 信任 GitHub 主机..."
mkdir -p ~/.ssh
ssh-keyscan -t rsa github.com >> ~/.ssh/known_hosts 2>/dev/null
chmod 600 ~/.ssh/known_hosts

# ====================== 2. 检查并清空远程仓库（删除所有分支） ======================
echo "[2/7] 检查并清空远程仓库（删除所有分支，仅保留 ${MAIN_BRANCH}）..."
# 获取远程所有分支（除 main）
REMOTE_BRANCHES=$(git ls-remote --heads $REMOTE_REPO | awk '{print $2}' | grep -v "refs/heads/${MAIN_BRANCH}")

# 删除远程多余分支
for BRANCH in $REMOTE_BRANCHES; do
  BRANCH_NAME=$(echo $BRANCH | sed 's/refs\/heads\///')
  echo "→ 删除远程分支：${BRANCH_NAME}"
  git push origin --delete $BRANCH_NAME
done

# ====================== 3. 检查并创建仓库（仅保留 main） ======================
echo "[3/7] 检查并创建仓库（默认分支：${MAIN_BRANCH}）..."
CHECK_REPO=$(curl -s -w "%{http_code}" "https://api.github.com/repos/${USERNAME}/${REPO_NAME}" \
  -H "Authorization: token ${ACCESS_TOKEN}")

if echo "$CHECK_REPO" | grep -q "Not Found"; then
  echo "→ 仓库不存在，创建空仓库（仅 ${MAIN_BRANCH} 分支）..."
  CREATE_REPO=$(curl -s -w "%{http_code}" -X POST "https://api.github.com/user/repos" \
    -H "Authorization: token ${ACCESS_TOKEN}" \
    -H "Content-Type: application/json" \
    -d "{
      \"name\": \"${REPO_NAME}\",
      \"default_branch\": \"${MAIN_BRANCH}\",
      \"auto_init\": false,
      \"private\": false
    }")
  if echo "$CREATE_REPO" | grep -q "\"id\":"; then
    echo "→ 仓库创建成功（仅 ${MAIN_BRANCH} 分支）！"
  else
    echo "→ 创建失败：$(echo "$CREATE_REPO" | grep -oP '(?<="message":")[^"]+')"
    exit 1
  fi
else
  echo "→ 仓库已存在（仅保留 ${MAIN_BRANCH} 分支），跳过创建。"
fi

# ====================== 4. 进入本地目录 ======================
echo "[4/7] 进入本地项目目录..."
cd $PROJECT_DIR || { echo "→ 目录不存在，退出！"; exit 1; }

# ====================== 5. 清理旧 Git 记录（核心：纯净初始化） ======================
echo "[5/7] 清理旧 Git 记录，准备全新镜像..."
rm -rf .git  # 销毁本地所有历史，确保纯净

# ====================== 6. 初始化 Git 并关联远程 ======================
echo "[6/7] 初始化 Git 仓库（仅 ${MAIN_BRANCH} 分支）..."
git init
git remote add origin $REMOTE_REPO

# ====================== 7. 强制推送全新镜像（核心：覆盖 main） ======================
echo "[7/7] 强制同步到 ${MAIN_BRANCH} 分支（全新初始化）..."
git checkout -b $MAIN_BRANCH  # 创建 main 分支
git add .
git commit -m "$COMMIT_MSG"
git push --force --set-upstream origin $MAIN_BRANCH  # 强制覆盖

# ====================== 结果反馈 ======================
if [ $? -eq 0 ]; then
  echo -e "\n✅ 全新初始化完成！远程仓库仅保留 ${MAIN_BRANCH} 分支，与本地完全一致："
  echo "→ 仓库地址：${REMOTE_REPO}"
  echo "→ 分支状态：仅 ${MAIN_BRANCH}（无任何多余分支）"
else
  echo -e "\n❌ 初始化失败，检查 SSH 密钥或网络。"
  exit 1
fi
