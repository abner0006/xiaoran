#!/data/data/com.termux/files/usr/bin/bash
# 功能：Gitee 远程到本地同步脚本（仅拉取远程更新）
# 说明：只把远程仓库的最新内容同步到本地，不推送本地文件，.git丢了会自动修复

# ====================== 配置信息（自己改） ======================
ACCESS_TOKEN="f1c2451a7f139023f6fa07ce4553333e"  # Gitee令牌（要有权限）
USERNAME="xiaoranmuze"          # Gitee用户名
REPO_NAME="update"                # 仓库名
PROJECT_DIR="/storage/emulated/0/.Auto/update"  # 本地文件放的地方
MASTER_BRANCH="master"          # 主分支名（Gitee默认master）
COMMIT_MSG="远程到本地同步：仅拉取远程变更"  # 同步说明
REMOTE_REPO="git@gitee.com:${USERNAME}/${REPO_NAME}.git"  # 远程仓库地址

# ====================== 1. 配置SSH，让本地能连Gitee ======================
echo "[1/7] 配置SSH，确保能连接Gitee..."
mkdir -p ~/.ssh
ssh-keyscan -t rsa gitee.com >> ~/.ssh/known_hosts 2>/dev/null
chmod 600 ~/.ssh/known_hosts

# ====================== 2. 不删远程分支（保留所有分支） ======================
echo "[2/7] 保留所有远程分支，不删除..."
# 下面是原始删分支的代码，现在注释掉不用了
REMOTE_BRANCHES=$(git ls-remote --heads $REMOTE_REPO | awk '{print $2}' | grep -v "refs/heads/${MASTER_BRANCH}")
# for BRANCH in $REMOTE_BRANCHES; do
#   BRANCH_NAME=$(echo $BRANCH | sed 's/refs\/heads\///')
#   echo "→ 删除远程分支：${BRANCH_NAME}"
#   git push origin --delete $BRANCH_NAME
# done

# ====================== 3. 检查仓库是否存在，没有就新建 ======================
echo "[3/7] 检查仓库是否存在..."
CHECK_REPO=$(curl -s -w "%{http_code}" "https://gitee.com/api/v5/repos/${USERNAME}/${REPO_NAME}" \
  -H "Authorization: token ${ACCESS_TOKEN}")

if echo "$CHECK_REPO" | grep -q "Not Found"; then
  echo "→ 仓库不存在，创建新仓库..."
  CREATE_REPO=$(curl -s -w "%{http_code}" -X POST "https://gitee.com/api/v5/repos" \
    -H "Authorization: token ${ACCESS_TOKEN}" \
    -H "Content-Type: application/json" \
    -d "{
      \"name\": \"${REPO_NAME}\",
      \"default_branch\": \"${MASTER_BRANCH}\",
      \"auto_init\": false,
      \"private\": false,
      \"access_token\": \"${ACCESS_TOKEN}\"
    }")
  if echo "$CREATE_REPO" | grep -q "\"id\":"; then
    echo "→ 仓库创建成功！"
  else
    echo "→ 创建失败：$(echo "$CREATE_REPO" | grep -oP '(?<="message":")[^"]+')"
    exit 1
  fi
else
  echo "→ 仓库已存在，不用新建..."
fi

# ====================== 4. 进入本地文件所在的目录 ======================
echo "[4/7] 进入本地项目目录..."
cd $PROJECT_DIR || { echo "→ 目录找不到，退出！"; exit 1; }

# 核心：拉取远程最新内容到本地（只远程→本地）
echo "[4/7 补充] 拉取远程最新更新到本地..."
if [ -d ".git" ]; then
  git fetch origin  # 同步远程信息
  git pull origin $MASTER_BRANCH --rebase  # 把远程内容合并到本地
else
  echo "→ 本地没初始化仓库，会自动初始化并同步远程内容..."
fi

# ====================== 5. 保留本地历史，不删除.git ======================
echo "[5/7] 保留本地Git历史，不清理..."
# 下面是原始删.git的代码，现在注释掉不用了
# rm -rf .git

# 自动修复.git目录（如果不小心删了）
echo "[5/7 补充] 检查.git是否存在，丢了就修复..."
if [ ! -d ".git" ]; then
  echo "→ .git丢了，重新建一个并同步远程内容..."
  git init
  git remote add origin $REMOTE_REPO
  git fetch origin  # 拉远程记录
  git reset --hard origin/$MASTER_BRANCH  # 把远程内容同步到本地
fi

# ====================== 6. 初始化Git并关联远程仓库 ======================
echo "[6/7] 初始化Git并关联远程..."
git init  # 已有.git的话，这步不影响
git remote add origin $REMOTE_REPO  # 已有关联的话，这步不影响

# 同步远程分支信息
echo "[6/7 补充] 同步远程分支信息..."
git fetch origin

# ====================== 7. 只拉取远程内容，不推送本地文件 ======================
echo "[7/7] 确认远程内容已同步到本地，不推送本地变更..."
# 切换到主分支（确保在正确分支接收远程内容）
if git show-ref --verify --quiet "refs/heads/${MASTER_BRANCH}"; then
  git checkout $MASTER_BRANCH
else
  git checkout -b $MASTER_BRANCH  # 没有就新建
fi

# 下面是推送本地内容的代码，现在注释掉不用了（不推送到远程）
# git add .
# git commit -m "$COMMIT_MSG"
# git push --set-upstream origin $MASTER_BRANCH

# ====================== 结果提示 ======================
if [ $? -eq 0 ]; then
  echo -e "\n✅ 远程到本地同步完成！"
  echo "→ 仓库地址：${REMOTE_REPO}"
  echo "→ 分支：保留所有分支"
  echo "→ 同步结果：远程最新内容已到本地（本地文件没推上去）"
else
  echo -e "\n❌ 同步失败，检查SSH或网络..."
  exit 1
fi
